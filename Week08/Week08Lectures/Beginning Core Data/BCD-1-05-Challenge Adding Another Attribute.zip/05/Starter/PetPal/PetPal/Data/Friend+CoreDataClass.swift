//
//  Friend+CoreDataClass.swift
//  PetPal
//
//  Created by Brian on 8/1/18.
//  Copyright © 2018 Razeware. All rights reserved.
//
//

import Foundation
import CoreData


public class Friend: NSManagedObject {

}

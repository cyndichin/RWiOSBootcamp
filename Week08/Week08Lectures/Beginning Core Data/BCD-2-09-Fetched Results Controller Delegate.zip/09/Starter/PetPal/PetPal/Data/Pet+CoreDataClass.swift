//
//  Pet+CoreDataClass.swift
//  PetPal
//
//  Created by Brian on 8/8/18.
//  Copyright © 2018 Razeware. All rights reserved.
//
//

import Foundation
import CoreData


public class Pet: NSManagedObject {

}

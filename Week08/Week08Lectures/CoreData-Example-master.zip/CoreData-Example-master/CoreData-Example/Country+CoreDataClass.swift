//
//  Country+CoreDataClass.swift
//  CoreData-Example
//
//  Created by leanne on 10/18/16.
//  Copyright © 2016 leanne63. All rights reserved.
//

import Foundation
import CoreData


public class Country: NSManagedObject {

}

//: [⇐ Previous: 01 - Introduction](@previous)
//: ## Episode 02: Xcode Playgrounds
import Foundation

var str = "Hello, playground"

//: [⇒ Next: 03 - Booleans & Comparison Operators](@next)

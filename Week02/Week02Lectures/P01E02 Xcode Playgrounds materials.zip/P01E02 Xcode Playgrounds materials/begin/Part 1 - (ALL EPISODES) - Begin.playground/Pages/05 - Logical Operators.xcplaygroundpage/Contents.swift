//: [⇐ Previous: 04 - Challenge - Booleans & Comparison Operators](@previous)
//: ## Episode 05: Logical Operators

let passingGrade = 50
let studentGrade = 50
let chrisGrade = 49
let samGrade = 99

//: [⇒ Next: 06 - Challenge - Logical Operators](@next)

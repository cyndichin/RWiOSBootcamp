//: ## Episode 02: Xcode Playgrounds
import Foundation

var str = "Hello, playground"

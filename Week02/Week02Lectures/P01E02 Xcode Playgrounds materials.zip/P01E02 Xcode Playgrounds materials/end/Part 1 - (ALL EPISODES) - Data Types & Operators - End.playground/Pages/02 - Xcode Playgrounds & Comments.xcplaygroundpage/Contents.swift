//: [⇐ Previous: 01 - Introduction](@previous)
//: ## Episode 02: Xcode Playgrounds
import Foundation

var welcomeMessage = "Hello, playground"

// The code below prints out a goodbye message
// Yet another comment

//let goodbyeMessage = "See you soon!"
//print (goodbyeMessage)

/* This is a comment
 spread out over a few lines.
 Also, a haiku! */

//: [⇒ Next: 03 - Booleans & Comparison Operators](@next)

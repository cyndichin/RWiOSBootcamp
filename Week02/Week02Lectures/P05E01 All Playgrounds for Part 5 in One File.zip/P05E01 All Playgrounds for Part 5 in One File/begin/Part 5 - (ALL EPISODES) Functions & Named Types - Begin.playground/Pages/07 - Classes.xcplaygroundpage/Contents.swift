//: [⇐ Previous: 06 - Challenge - Structures](@previous)
//: ## Episode 07: Classes

// -----------------------------------
//struct Actor {
//  let name: String
//  var filmography: [String] = []
//}
// -----------------------------------


//: [⇒ Next: 08 - Challenge - Classes](@next)

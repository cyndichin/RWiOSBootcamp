//: [⇐ Previous: 04 - Challenge - Functions](@previous)
//: ## Episode 05: Structures

// ----------------------------------
//typealias Student = (name: String, grade: Int, pet: String?)
// ----------------------------------




//: [⇒ Next: 06 - Challenge - Arrays](@next)

//: [⇐ Previous: 03 - Challenge - Tuples](@previous)
//: ## Episode 04: Arrays

//let pastries: [String] = ["cookie", "cupcake", "donut", "pie"]

var pastries: [String] = []
pastries.append("cookie")
pastries.append("danish")

pastries += ["cupcake", "donut", "pie", "brownie"]

//: [⇒ Next: 05 - Operating on Arrays](@next)
